
import React from 'react';
import { Box, FormControl, InputLabel, Select, MenuItem, SelectChangeEvent } from '@mui/material';
import './filter.css'

const Filter: React.FC = () => {
  const [filter, setFilter] = React.useState<string>('');

  const handleChange = (event: SelectChangeEvent) => {
    setFilter(event.target.value as string);
  };

  return (
    <Box width="200px">
      <FormControl fullWidth variant="outlined">
        <InputLabel id="filter-label">Фильтр</InputLabel>
        <Select
          labelId="filter-label"
          value={filter}
          onChange={handleChange}
          label="Фильтр"
        >
          <MenuItem value="">
            <em>None</em>
          </MenuItem>
          <MenuItem value="price">Цена</MenuItem>
          <MenuItem value="duration">Длительность</MenuItem>
        </Select>
      </FormControl>
    </Box>
  );
};

export default Filter;

