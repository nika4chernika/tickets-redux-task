import React from 'react';
import { useAppSelector } from '../../hooks';
import FlightCard from '../FlightCard/FlightCard';
import './flightList.css'

const FlightList: React.FC = () => {
  const tickets = useAppSelector((state) => state.flights.tickets);

  return (
    <div className='list'>
      {tickets.map(ticket => (
        <FlightCard key={ticket.id} {...ticket} />
      ))}
    </div>
  );
};

export default FlightList;
