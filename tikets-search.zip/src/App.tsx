import React, { useEffect } from "react";
import { Container, Box } from "@mui/material";
import Filter from "./Components/Filter";
import FlightList from "./Components/FlightList/FlightList";
import { useAppDispatch } from "./hooks";
import { setTickets, ticketList, sortTicketsByPrice } from "./slices/flightSlice";
import "./App.css";

const App: React.FC = () => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(setTickets(ticketList));
  }, [dispatch]);

  const handleSortByPrice = () => {
    dispatch(sortTicketsByPrice());
  };

  return (
    <div>
      <Container>
        <div className="header">
          <img src="./images/logo-main.png" alt="logo" className="logo"/>
          <h1 className="h1">Поиск авиабилетов</h1>
        </div>
        <Box display="flex">
          <Filter />
          <Box flex="1" paddingLeft={2}>
            <div className="filter-from-to">
              <button onClick={handleSortByPrice} className="button-toggle">Самый дешевый</button>
              <button className="button-toggle">Самый быстрый</button>
              <button className="button-toggle">Самый оптимальный</button>
            </div>
            <FlightList />
            <button className="button-more">Загрузить еще билеты</button>
          </Box>
        </Box>
          
      </Container>
    </div>
  );
};

export default App;
